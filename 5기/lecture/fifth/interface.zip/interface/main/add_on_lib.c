#include "add_on_lib.h"
#include <stdio.h>

void iam_add_on (void)
{
    printf("I\'m add on\n");
}