#ifndef __RECEIVER_H__
#define __RECEIVER_H__

void recv_command_from_outbound (void);

#endif